var getSpeechEngine = function(lang, text){
	var cfg = (lang=="es")?"eurspanishmale":"usenglishfemale";	
	return "http://www.ispeech.org/p/generic/getaudio?text="+text+"&voice="+cfg+"&speed=0&action=convert";
	//return "speach/himno.ogg"; // "http://translate.google.com/translate_tts?tl="+lang+"&q="+text;
}

var DEBUG = true;

var TRIGGER = 1;

window.SystemInfo={
	language: navigator.language,
	platform: navigator.platform,
	userAgent:navigator.userAgent,
	quality: 'high'/* User quality preference */
}

var ICONS={
	poster:"http://dribbble.s3.amazonaws.com/users/129778/screenshots/905019/atari-game-over.jpg",
	loading:"img/indicator.gif",
	play:"http://png-3.findicons.com/files/icons/1667/iconic/32/play_alt.png",
	pause:"https://cdn3.iconfinder.com/data/icons/pictofoundry-pro-vector-set/512/MediaPause-32.png",
	backward:"https://cdn2.iconfinder.com/data/icons/freecns-cumulus/16/519699-207_CircledBackward2-32.png",
	forward:"https://cdn2.iconfinder.com/data/icons/freecns-cumulus/16/519700-208_CircledForward2-32.png",
	reload:"http://www.isvolunteers.org/sfPHPCaptchaPlugin/images/reload.png", 
	resize:"http://www.mricons.com/store/png/113992_29835_32_fullscreen_gtk_icon.png",
	about:"http://karthikv.net/images/about.png", 
	menu:"http://aux.iconpedia.net/uploads/list-window-icon-32.png",
	test:"https://cdn1.iconfinder.com/data/icons/windows-8-metro-style/32/test_tube.png",
	share:"https://cdn0.iconfinder.com/data/icons/cosmo-layout/40/share-32.png",
	social:"http://www.webrunnermedia.com/wp-content/uploads/2012/01/Social-Media-Marketing.png",
	error:"img/error.png",
	warning:"img/warning.png"
};

var Queue = function (parent, node, attrs){
	return (function(){
		var elements = [];
		var onEnd = function(){Notify.fire(attrs.fullname+".onEnd");};
		var onBegin = function(){Notify.fire(attrs.fullname+".onBegin");};
		var onPrepare = function(){Notify.fire(attrs.fullname+".onPrepare");};
		var prepare = function(){Notify.fire(attrs.fullname+".prepare");setTimeout(onPrepare,TRIGGER);};	
		var begin = function(){Notify.fire(attrs.fullname+".begin");setTimeout(onBegin,TRIGGER);};		
		var end = function(){Notify.fire(attrs.fullname+".end");setTimeout(onEnd,TRIGGER);};
		return ({
			attrs:attrs,
			elements:elements,
			length:function(){return elements.length;},
			add:function(element){
				elements.push(element);
			},
			each:function(fn){
				for(var e in elements){
					fn.apply(this, [elements[e], e]);
				}
			},
			get:function(n){
				return elements[n];
			},
			last:function(){
				return (elements.length>0)?elements[elements.length-1]:null;
			},
			prepare:function(fn){if(fn) prepare = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".prepare");prepare.call();}},			
			begin:function(fn){if(fn) begin = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".begin");begin.call();}},
			end:function(fn){if(fn) end = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".end");end.call();}},			
			onPrepare:function(fn){if(fn) onPrepare = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".onPrepare");onPrepare.call();}},
			onBegin:function(fn){if(fn) onBegin = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".onBegin");onBegin.call(); }},
			onEnd:function(fn){if(fn) onEnd = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".onEnd");onEnd.call(); }}
		});
	})();
};

var model = Queue(); 
var controller;
/* Remember Clean onReaload */
var players = {};
var metas={};
var regions={};
var prefetchs = {};
var xsltmodels = {}; /* Memory of XSLT documents */
var milestones = {}; /* Time Marks for Seek back */
/* --------------------- */

function onYouTubePlayerReady(playerId) {
	var ytplayer = ytplayer || document.getElementById(playerId);
	ytplayer.addEventListener("onStateChange", "onStateChange");
	//ytplayer.addEventListener("onApiChange", "onApiChange");
}

function onApiChange(evt){console.log("onApiChange");}

function onStateChange(evt){	
	for(var vid in players){
		try{
			players[vid].onStateChange();
		}catch(err){
			console.log("Player Remove "+vid);
			delete players[vid];
		}
	}
}
		
YUI.add('smlplayer', function (Y) {	
	var WebPlayer =  (function(id){	
		var ids_gen = {};
		var ids = {};	
		function guid(tagName) {
			if(ids_gen[tagName]){				
				return "smlplayer-"+tagName+"-"+(ids_gen[tagName]+=1);
			}else{
				return "smlplayer-"+tagName+"-"+(ids_gen[tagName]=1);
			}
		}
		
		var about = (function(){
			var dialog = new Y.Panel({
			contentBox : Y.Node.create('<div id="dialog" />'),
			bodyContent: '<div class="message">'+
						'SMLearning Player :: ivandcl@gmail.com (c) - 2013 '+
						'</div>',
			width      : 510,
			zIndex     : 6,
			centered   : true,
			modal      : false, // modal behavior
			render     : '.example',
			visible    : false, // make visible explicitly with .show()
			buttons    : {
				footer: [				
						{
						name     : 'proceed',
						label    : 'OK',
						action   : function(){
								this.hide();						
							}
						}
					]
				}
			});
			return (function(info){
				var body = '<pre class="message">'+info+'\nSMLearning Player 2 alpha\nivandcl@gmail.com (c) - 2013 '+'</pre>';
				dialog.bodyNode.setHTML(body);
				console.log(dialog);
				dialog.show();
			});
		})();

	   var busy = function(t){		
			var s = window.performance.now();
			var e = window.performance.now();
			while( (e - s) <= t ) e = window.performance.now();
		}
		
		/*RTClock*/
/*----*/var Clock = (function(){
			var time=0; 			/* current time*/		
			var listeners = {}; 	/* callback */
			var stack =  []; 	/* clock stack */
			var that = this;
			var src;
			var state = 0;		
			var System = (function (){
				var resolution = 500; 
				var isEnabled = false;
				var isStop = true;
				var now = (window.performance && window.performance.now)?(function(){return window.performance.now();}):(function(){return (new Date()).getTime()});
				var lastTime = now();
				var runner = function runner(){					
					if(isEnabled){
						console.log("Clock system.isRunning");
						var delta = now()-lastTime;
						Clock.setTime(time+=delta);
						lastTime = now();
						isStop = false;
						setTimeout(runner, resolution);
					}else{
						isStop = true;
						console.log("NOT ENABLE");
					}				
				};	
				var beginTime = 0;
				return ({
					enable:function(e){isEnabled=e;console.log("Clock system "+e);},
					start:function(){
						beginTime = time;
						var d = now() - lastTime;
						lastTime += d;
						isEnabled=true;
						console.log("Clock.start.istop:"+isStop);
						if(isStop){										
							setTimeout(runner, 1);
						}
					},
					stop:function(){
						lastTime = now();
						isEnabled=false;
					},
					seek:function(offset){	
						var	ntime = time+offset;
						ntime = ntime>beginTime?ntime:beginTime;
						lastTime = now();
						Notify.fire("Clock.seek\t"+ntime);
						Clock.setTime(ntime);
					}
				});
			});
			
			stack[0]=System();
			var src=stack[0];
			var isPaused = true;
			
			var resume = function(){
				isPaused = false;
				src.start();
			}
				
			return {
				reset:function(){
					Notify.fire("Clock.reset");
					for(var k in listeners){
						if(stack.length>1){
							stack.pop().enable(false);
						}
					}
					stack[0].enable(false);
					for(var k in listeners){
						if(k.indexOf("system-")!=0)
							delete listeners[k];
					}
					time = 0;
					state = 0;
				},
				state:function(nstate){if(typeof nstate!='undefined'){state=nstate; }else{return state;}},
				remove:function (k){
					delete listeners[k];
				},
				add: function (k, fn){
					listeners[k] = fn;
				},
				setSource:function (clock){
					Notify.fire("Clock.setSource\t"+clock);
					console.log("Clock.stack.start:"+stack.length);
					src.enable(false);
					if(typeof clock == 'undefined'){						
						if(stack.length>1){
							stack.pop();
							clock = stack[stack.length-1];
						}else{
							clock = stack[0];
						}
					}else{
						stack.push(clock);
					}
					console.log("Clock.stack.end:"+stack.length);
					src=clock;
					src.enable(true);
				},
				setTime:function(val){				
					time = val;				
					for(var k in listeners){
						setTimeout(listeners[k],10,k,time);
					}
				},
				getTime:function(){				
					return time;
				},
				seek:function(offset){
					src.seek(offset);
				},
				pause:function (){	
					Notify.fire("Clock.pause");
					state = 2;
					isPaused = true;
					src.stop();		
				},
				start:function (){
					Notify.fire("Clock.start");
					state = 1;
					if(isPaused)
						src.start();
				},
				stop:function (){
					Notify.fire("Clock.stop");
					Clock.pause.apply();
					isPaused = true;
					state = 0;
					Clock.setTime(0);
				},			
				toString:function(){
					var SSS = time % 1000;
					var sec = ((time - SSS) % 60000)/1000;
					var min = ((time-SSS-sec*1000) % 3600000)/60000;
					var hh = ((time-SSS-sec*1000-min*60000))/3600000;
					return hh+":"+min+":"+sec+"."+Math.round(SSS/100);
				}
			};	
		})();
			
		var getText = function (node){
			var str = "";
			if(node.nodeType == 3) return node.nodeValue;
			if (node.nodeType==1){ /* element */
				children = node.childNodes;
				for(var i=0;i<children.length;i+=1){
					str += getText(children[i]);
				}					
			}
			return str;
		}
		
		var createYTPlayer = (function (attrs, onEnd){
			var vid = attrs.src;
			var playerId = "ytplayer_"+vid;
			var ytplayer;
			var states = ["unstarted", "ended", "playing", "paused", "buffering", "video cued"];
			Y.one("#smlplayer-sandbox").append(Y.Node.create('<div id="myapiytplayer-'+vid+'" class="smlplayer-screen"></div>'));		
			var params = { allowScriptAccess: "always", allowFullScreen: "true", wmode:"transparent"};
			var atts = {id: playerId, style:"position:absolute;top:0px;"};
			var flashvar = {};
			swfobject.embedSWF("https://www.youtube.com/e/"+vid+"?enablejsapi=1&playerapiid=ytplayer_"+vid+"&controls=0&autoplay=0&autohide=0&rel=0&iv_load_policy=3&showinfo=0",
							   'myapiytplayer-'+vid, "1", "1", "8", null, flashvar, params, atts);
			var isReady = false;
			players[vid] = {
				onStateChange:function(e){
					ytplayer = ytplayer || document.getElementById(playerId);
					if(ytplayer){ 
						e = ytplayer.getPlayerState();
					}else{
						return; /* it is not with me :'( */
					}
					console.log(vid+" is "+states[e+1]);
					for(var i=0;i<observers.length;i++){
						(observers[i])(e);
					}
					if(!isReady){
						isReady=true;
						setTimeout(onEnd,1);
					}	
				}
				/*,onApiChange:function(e){console.log(e);} //Future Work! */
			};
			
			var observers = [];
			attrs.beginClip = attrs.beginClip || 0;
			return ({
				state:function(){
					ytplayer = ytplayer || document.getElementById(playerId);
					return (ytplayer.getPlayerState)?ytplayer.getPlayerState():-1;
				}
				,ui:function (){
					return Y.one("#"+playerId);
				}
				,play: function (){
					ytplayer = ytplayer || document.getElementById(playerId);
					ytplayer.playVideo();
				},
				pause: function (){
					ytplayer = ytplayer || document.getElementById(playerId);
					ytplayer.pauseVideo();
				},
				stop: function (){
					ytplayer = ytplayer || document.getElementById(playerId);
					ytplayer.stopVideo();
				},
				seekTo: function(secs){
					ytplayer = ytplayer || document.getElementById(playerId);
					ytplayer.seekTo(secs, true);
				},			
				getCurrentTime:function(secs){
					ytplayer = ytplayer || document.getElementById(playerId);
					return ytplayer.getCurrentTime();
				},
				getDuration:function(secs){
					ytplayer = ytplayer || document.getElementById(playerId);
					return ytplayer.getDuration();
				},
				seek:function(secs){
					ytplayer = ytplayer || document.getElementById(playerId);
					var ntime = secs+ytplayer.getCurrentTime();
					ntime = ntime<attrs.beginClip?attrs.beginClip:ntime;
					ntime = ntime>ytplayer.getDuration()?ytplayer.getDuration():ntime;					
					ytplayer.seekTo(ntime, true);
				},
				add:function (fn){
					observers.push(fn);
				}
			});
		});
		
		var createHTMLMedia = function(type, attrs, fnCanplay){
			var player;
			var observers = [];
			if(type=="audio"){
				player= new Audio();
			}else{
				player = document.createElement('video');
			}
			
			var listEvent = ["waiting", "playing", "ended", "canplaythrough", "timeupdate", "pause", "loadedmetadata", "progress", "loadstart"];
			for(var i =0; i<listEvent.length; i++){
				var ev = ""+listEvent[i];
				player.addEventListener(ev,function(e){
					for(var i in observers){
						observers[i].call();
					}					
				});	
			}
						
			/*canplaythrough: have enough data to play*/
			player.addEventListener("canplay",function(e){
				fnCanplay.apply();				
			});					
			//player.setAttribute("controls","controls");
			player.setAttribute("src",attrs.src);
			player.load();
			player.setAttribute("width","100%");
			player.setAttribute("height","100%");
			attrs.beginClip = attrs.beginClip || 0;		
			
			//prefetchs[attrs.src] = player;	
			return ({
				ui:function (){return player;},
				state:function(){
					if(player.ended) return 0;
					if(player.paused) return 2;					
					if(player.readyState==4) return 1;
					return -1;
				}
				,play: function (){player.play();},
				pause: function (){player.pause();},
				stop: function (){player.pause(); player.setAttribute("src","");},
				seekTo: function(secs){try{player.currentTime=secs;}catch(err){}},			
				getCurrentTime:function(secs){return player.currentTime;},
				getDuration:function(secs){return player.duration;},
				seek:function(secs){
					try{
						var ntime = secs+player.currentTime;
						ntime = ntime<attrs.beginClip?attrs.beginClip:ntime;
						ntime = ntime>player.duration?player.duration:ntime;
						console.log(ntime);
						Notify.fire("Clock.seek\t"+ntime);						
						player.currentTime=ntime;
					}
					catch(err){Notify.fire("Clock.seek\t"+secs+"\terror\t"+err);		}
				},
				add:function (fn){observers.push(fn);}
			});
		}
		
		var str = function(obj){
			var pairs = "";
			for(var n in obj)
				pairs += n+": "+obj[n]+"\n";
			return pairs;
		}
				
		var root;
		var url;		
		var that = this;
		
		var getAttributes = function(node){
			var attrs = {};
			if (node.nodeType == 1) { // element		
				if (node.attributes.length > 0) {
					for (var j = 0; j < node.attributes.length; j++) {
						var attribute = node.attributes.item(j);
						attrs[attribute.nodeName] = attribute.nodeValue;
					}
				}
			}
			attrs.tagName = node.tagName;
			if(typeof attrs.id == 'undefined'){ 
				attrs.id = guid(attrs.tagName);
			}		
			if(typeof ids[attrs.id] != 'undefined'){
				var nid = guid(attrs.tagName);				
				ui.error(true,attrs.tagName+" id='"+attrs.id+"' is not unique, was replace by '"+nid+"'");
				attrs.id=nid;								
			}
			ids[attrs.id]=true;
			attrs.fullname = attrs.tagName+"@"+attrs.id;			
			if(typeof attrs.region != 'undefined' && typeof regions[attrs.region] == 'undefined'){
				ui.error(true,attrs.fullname+" region='"+attrs.region+"' is not defined");
				exit();
			}			
			return attrs;
		}
	
		function transformation(xslt, url, fnCallback) {
			var xsltmodel = xsltmodels[xslt];
			if(!xsltmodel){
				getFileContent(xslt+"?seed="+Math.random(), function(doc){xsltmodels[xslt] = doc;transformation(xslt, url, fnCallback);});
			}else{
				getFileContent(url+"?seed="+Math.random(), function(xdata){
					var resultDocument; 
					if (window.ActiveXObject){resultDocument = xdata.transformNode(xsltmodel);} /*IE*/
					else if (document.implementation && document.implementation.createDocument){/*ELSE*/
						var xsltProcessor = new XSLTProcessor();
						xsltProcessor.importStylesheet(xsltmodel);
						resultDocument = xsltProcessor.transformToFragment(xdata, document);
					}
					fnCallback(resultDocument);					
				});	
			}
		}
		
//-->	/*Create uiplayer*/
		var ui = (function(){	
			var logColors ={info:"blue",warining:"golden", error:'red'};
			var pfx = ["webkit", "moz", "ms", "o", ""];
			function RunPrefixMethod(obj, method) {				
				var p = 0, m, t;
				while (p < pfx.length && !obj[m]) {
					m = method;
					if (pfx[p] == "") {
						m = m.substr(0,1).toLowerCase() + m.substr(1);
					}
					m = pfx[p] + m;
					t = typeof obj[m];
					if (t != "undefined") {
						pfx = [pfx[p]];
						return (t == "function" ? obj[m]() : obj[m]);
					}
					p++;
				}
			}
		
			var dRoot = Y.one("#"+id);
			//dRoot.setStyle("display", "inline");
			
			var ipanels = Y.Node.create('<div id="smlplayer-panels" class="smlplayer-panels"></div>');
			ipanels.setStyle("width", "100%");
			ipanels.setStyle("textAlign","center");
			ipanels.setStyle("clear", "both");
			ipanels.setStyle("backgroundColor","inherit");
			dRoot.append(ipanels);			
			
			var panels = Y.Node.create('<div id="smlplayer-panels-main" class="smlplayer-panels-main"></div>');
			panels.setStyle("display","inline-block");
			
			ipanels.append(panels);
			
			var t2s = function(time){
				var SSS = time % 1000;
				var sec = ((time - SSS) % 60000)/1000;
				var min = ((time-SSS-sec*1000) % 3600000)/60000;
				var hh = ((time-SSS-sec*1000-min*60000))/3600000;
				return hh+":"+min+":"+sec;
			}
			
			var hightligth = function (id, speed){
				speed = speed || 400;
				var dom = document.getElementById(id);
				if(!dom)return;
				var stage = 0;
				var original = dom.style.backgroundColor;
				function step(){
					var h = Math.ceil(255*Math.sin(stage));
					dom.style.backgroundColor = "rgba(255,255,"+h+",0.7)";
					dom.html = h;
					if(stage<1){
						stage +=0.1;
						setTimeout(step, speed);
					}else{
						dom.style.backgroundColor=original;
					}
				}
				setTimeout(step, 0);
			}
		
			var right = Y.Node.create('<div id="smlplayer-container-right" class="smlplayer-container-right"></div>');
			right.setStyle("float", "right");
			right.setStyle("backgroundColor","#333");
			right.hide();
			panels.append(right);			
			
			var container = Y.Node.create('<div id="smlplayer-container" class="smlplayer-container"></div>');
			//container.setStyle("float", "left");
			
			panels.append(container);
			
			var treee = Y.Node.create('<ul id="smlplayer-tree-0" class="tree"></ul>');
			dRoot.append(treee);
			
			var logg = Y.Node.create('<ul id="smlplayer-log" class="log"></ul>');
			logg.setStyle("text-align","left");
			dRoot.append(logg);
						
			var screen = Y.Node.create('<div id="smlplayer-screen" class="smlplayer-screen"></div>');
			var controls = Y.Node.create('<div id="smlplayer-controls" class="smlplayer-controls"></div>').set('role', 'toolbar');
			
			var controlsRight = Y.Node.create('<div id="smlplayer-controls-right" class="smlplayer-controls-right"></div>');
			controlsRight.setStyles({'float':'right'});
			controls.append(controlsRight);
			
			var clock = Y.Node.create('<span class="smlplayer-controls-clock"></span>');
			controlsRight.append(clock);
			
			var plugins = Y.Node.create('<div id="smlplayer-controls-plugins" class="smlplayer-controls-plugins"></div>');
			plugins.setStyles({'float':'right'});
			controls.append(plugins);
			
			var statusBox = Y.Node.create('<div id="smlplayer-busy" style="height:32px;position:relative;float:right;"></div>');
			controls.append(statusBox);
			
			var errorBox = Y.Node.create('<div id="smlplayer-busy" style="height:32px;position:relative;float:right;"></div>');
			controls.append(errorBox);
			
			var prefetch = Y.Node.create('<div id="smlplayer-prefetch" style="display:none"></div>');
			var sandbox = Y.Node.create('<div id="smlplayer-sandbox" style="z-index:0;position:absolute;top:1px;"></div>');
						
			container.append(prefetch);
			container.append(sandbox);
			container.append(screen);
			container.append(controls);		
			
			var callback = function(k, time){};
			Clock.add("system-uiclock", function(k, time){clock.setHTML(t2s(time));});
						
			var busy = function(){var ico = new Image();ico.width=32;ico.height=32;ico.src = ICONS.loading;ico.title = "Busy";return ico;};
			var warning = function(){var ico = new Image();ico.width=32;ico.height=32;ico.src = ICONS.warning;ico.title = "Warning";return ico;};
			var error = function(){var ico = new Image();ico.width=32;ico.height=32;ico.src = ICONS.error;ico.title = "Error";return ico;};
			
			var nError = (function(){				
				return {
					show:function(msg){
						var ico = error();
						ico.title = msg || "Error";	
						errorBox.append(ico);
						errorBox.show();
					},
					hide:function(){errorBox.hide();}
				};
			})();
			
			var nBusy = (function(){				
				return {
					show:function(msg){
						var ico = busy();
						ico.title = msg?msg:"Busy";	
						statusBox.setHTML(ico);
						statusBox.show();
					},
					hide:function(){statusBox.hide();}
				};
			})();		
			
			var setStyle = function(node, attrs){
				for(var n in attrs)
					node.setStyle(n, attrs[n]);
			}
			
			var tree = function(deep,text){
				if(!DEBUG) return;
				var id = "smlplayer-tree-"+deep;
				var n = Y.one("#"+id);
				if(!n){
					n = Y.Node.create('<ul id="'+id+'"></ul>');
					li = Y.Node.create('<li/>');
					li.append(n);
					Y.one("#smlplayer-tree-"+(deep-1)).append(li);
				}
				n.append("<li>"+text+"</li>");
			};
						
			var log = function(){
				if(!DEBUG) return;
				var now = (new Date()).getTime();
				var id = "smlplayer-log-"+now;
				var n = Y.one("#"+id);
				if(!n){
					n = Y.Node.create('<ul id="'+id+'"></ul>');
					li = Y.Node.create('<li/>');
					li.append(n);
					logg.append(li);
				}
				var args = Array.prototype.slice.call(arguments, 0);
				n.append("<li><pre>"+parseInt(window.performance.now())+"\t"+Clock+"\t"+args.join("\t")+"</pre></li>");
			};
			
			var isFullscreen = false;
			var fullscreen = function(){
				if(RunPrefixMethod(document.getElementById(id), "RequestFullscreen")){	
					isFullscreen=true;				
					original.screen = [];
					original.screen[0] = parseInt(screen.getComputedStyle("width"), 10);
					original.screen[1] = parseInt(screen.getComputedStyle("height"),10);
					for(var name in regions){
						var r = regions[name];
						var cWidth = parseInt(r.getComputedStyle("width"),10);
						var cHeight =  parseInt(r.getComputedStyle("height"),10);
						var cTop =  parseInt(r.getComputedStyle("top"),10) || 0;
						var cLeft = parseInt(r.getComputedStyle("left"),10) || 0;
						var cFont = parseInt(r.getComputedStyle("font-size"),10) || 1;
						original[name]=[cWidth, cHeight, cTop, cLeft, cFont];	
					}
					resize(window.innerWidth,window.innerHeight); /* get value from user agent */
				}
			}
			var original= {};
			var toogleFullscreen = function (){
				if (RunPrefixMethod(document, "FullScreen") || RunPrefixMethod(document, "IsFullScreen")){
					isFullscreen=false;	
					ui.log("Resize","Restart");					
					screen.setStyle("width",original.screen[0]);
					screen.setStyle("height",original.screen[1]);
					for(var name in regions){
						var o = original[name];
						var r = regions[name];
						r.setStyle("width",o[0]+"px");
						r.setStyle("height",o[1]+"px");
						r.setStyle("top",o[2]+"px");
						r.setStyle("left",o[3]+"px");
						r.setStyle("font-size",o[4]+"px");
					}
					RunPrefixMethod(document, "CancelFullScreen");
				}else{
					original.screen = [];
					original.screen[0] = parseInt(screen.getComputedStyle("width"), 10);
					original.screen[1] = parseInt(screen.getComputedStyle("height"),10);
					for(var name in regions){
						var r = regions[name];
						var cWidth = parseInt(r.getComputedStyle("width"),10);
						var cHeight =  parseInt(r.getComputedStyle("height"),10);
						var cTop =  parseInt(r.getComputedStyle("top"),10) || 0;
						var cLeft = parseInt(r.getComputedStyle("left"),10) || 0;
						var cFont = parseInt(r.getComputedStyle("font-size"),10) || 1;
						original[name]=[cWidth, cHeight, cTop, cLeft, cFont];	
					}					
					//alert(document.getElementById(panels.getAttribute("id")));
					
					if(document.getElementById("smlplayer-panels-main").webkitRequestFullscreen){
						document.getElementById("smlplayer-panels-main").webkitRequestFullscreen();
					}else{
						RunPrefixMethod(document.getElementById("smlplayer-panels-main"), "RequestFullScreen");
					}
					
					var min = Math.min(window.screen.width,window.screen.height);					
					var w = parseInt(Y.one("#smlplayer-panels-main").getComputedStyle("width"), 10);
					var h = parseInt(Y.one("#smlplayer-panels-main").getComputedStyle("height"),10);
					
					var isLarge = (w<h);
					var proportion = Math.min(w,h)/Math.max(w,h);
					var nW;
					var nH; 
					if(isLarge){
						nW = min*proportion;
						nH = min;
					}else{
						nW = min;
						nH = min*proportion;
					}					
					
					//resize(nW,nH); /* get value from user agent */
				}
			};
			
			var resize = function(width, height){
				/* Relatives regions */
				var sWidth = parseInt(screen.getComputedStyle("width"), 10);
				var sHeight =  parseInt(screen.getComputedStyle("height"),10);
				var rW = width / sWidth;
				var rH = height / sHeight;
				ui.log("Resize",rW, rH);
				screen.setStyle("width",width);
				screen.setStyle("height",height);
				
				for(var name in regions){
					var r = regions[name];
					var cWidth = parseInt(r.getComputedStyle("width"),10);
					var cHeight =  parseInt(r.getComputedStyle("height"),10);
					var cTop =  parseInt(r.getComputedStyle("top"),10) || 0;
					var cLeft = parseInt(r.getComputedStyle("left"),10) || 0;					
					var cFont = parseInt(r.getComputedStyle("font-size"),10) || 1;
					
					var nWidth = (cWidth*rW);
					var nHeight =  (cHeight*rH);
					var nTop =  cTop*rH;// + (nHeight-cHeight)/2;
					var nLeft = cLeft*rW;// + (nWidth-cWidth)/2;
					var nFont = cFont*(rW+rH)/2;
					r.setStyle("width",nWidth+"px");
					r.setStyle("height",nHeight+"px");
					r.setStyle("top",nTop+"px");
					r.setStyle("left",nLeft+"px");
					r.setStyle("font-size",nFont+"px");
				}
			}
			
			var img = function(src){				
				var i = Y.Node.create('<img src="'+src+'" style="width:100%;height:100%"/>');	
				return i;
			}
			
			return {
				fullscreen:fullscreen,
				controls:controls,
				img:img,
				clock:function(time){clock.setHTML(t2s(time));},
				upatedIcon:function(id,icons,titles,state){
					var cm = Y.one(id);	
					if(!cm) return;
					var ico = new Image();
					ico.width=32;
					ico.height=32;
					ico.title = titles[state];
					ico.src = icons[state];
					cm.setHTML(ico);
				},
				t2s:t2s,
				hightligth:hightligth,
				tree:tree,
				logg:logg,
				right:right,
				sandbox:sandbox,
				toogle:toogleFullscreen,
				resize:resize,
				setStyle: setStyle,
				screen:screen,				
				prefetch:prefetch,				
				log:log,				
				busy:function(isBusy, msg){(isBusy)?nBusy.show(msg):nBusy.hide();},
				error:function(isBusy, msg){(isBusy)?nError.show(msg):nError.hide();},
				getBusy:function(){var node = Y.Node.create('<span/>');node.append(warning());return node;},
				addControl:function(name,icon,callback,css,attrs){
					attrs = attrs || {};
					var ico = new Image();
					ico.width=32;
					ico.height=32;
					ico.src = icon;
					ico.title = name;
					var bt = Y.Node.create('<a href="#"></a>');
					bt.setAttrs(attrs);
					bt.setStyles(css);
					bt.append(ico);
					bt.on('click', function (e){ e.preventDefault(); callback.apply();});
					controls.append(bt);					
				},
				addPlugin:function(name,icon,callback,css,attrs){
					attrs = attrs || {};
					var ico = new Image();
					ico.width=32;
					ico.height=32;
					ico.src = icon;
					ico.title = name;
					var bt = Y.Node.create('<a href="#"></a>');
					bt.setAttrs(attrs);
					bt.setStyles(css);
					bt.append(ico);
					bt.on('click', function (e){ e.preventDefault(); callback.apply();});
					plugins.append(bt);					
				},
				addRegion:function (attrs){					
					var id = attrs["id"];
					if(typeof id == 'string'){
						delete attrs["id"];
						var region = Y.Node.create('<div class="smlplayer-region"></div>');
						region.setAttribute("id",id);
						setStyle(region, attrs);
						screen.append(region);
						region.setStyle("display", "none");
						regions[id]=region;
					}
				},
				clean:function(){
					screen.setHTML("");
					prefetch.setHTML("");
					sandbox.setHTML("");
					treee.setHTML("");
					plugins.setHTML("");
					right.setHTML("");
				}
			}
		})();
		
		var playAfterLoad = true; /* Autoplay? */
		
		var reset = function(m,deep){
			m.onEnd(function(){});
			m.onBegin(function(){});
			m.onPrepare(function(){});
			m.prepare(function(){});
			m.begin(function(){});
			m.end(function(){});
			if(m.elements) for(var i=0;i<m.elements.length;i+=1){reset(m.elements[i]);}
		}
		
		var print = function(m,deep){
			ui.tree(deep,m.attrs.tagName+"@"+m.attrs.id);
			deep+=1;		
			if(m.elements) for(var i=0;i<m.elements.length;i+=1){
				var e = m.elements[i];
				print(e,deep);
			}
		}
		
//-->	/* Parser elements */
		var Parser = (function(){
			
			var xform = function (parent, node, attrs){			
				ui.log("Parse","xform",attrs.id);					
				var el = Factory(parent, node, attrs);
				el.show(function(){	
					Clock.pause();				
					var src = attrs.src;
					var template = attrs.template;
					transformation(template,src, function(eContent){						
						var content = Y.Node.create("<div/>");
						content.setHTML(eContent);													
						var fnController = eval(content.one("script").get("text"));	
						var xcontent = content.getHTML();
						regions[attrs.region].setHTML(xcontent);
						regions[attrs.region].show();
						var controller = fnController();
						controller.setElement(el);						
						var xClock = controller.clock(Clock);
						Clock.setSource(xClock);							
					});					
				});
				el.hide(function(){
					regions[attrs.region].hide();
				});
				parent.add(el);				
			} 
			
			var audio = function(parent, node, attrs){
				ui.log("Parse",attrs.fullname);								
				var player;
				var e = Factory(parent, node, attrs);
				e.prepare(function(){
					ui.busy(true,"Buffering");
					Clock.pause(-1);										
					player = createHTMLMedia("audio",attrs, function(){						
						ui.busy(false);						
						e.attrs.endClip = attrs.endClip || player.getDuration();
						e.attrs.dur = attrs.dur || (attrs.endClip-attrs.beginClip);
						Clock.start();
						setTimeout(e.onPrepare,TRIGGER);
						
					});								
				});				
				e.show(function (){player.play();});
				e.hide(function (){player.stop();});
				parent.add(e);
			}
		
			var speach = function(parent, node, attrs){				
				var language = node.getAttribute("language");
				var content = encodeURIComponent(node.getAttribute("content"));
				var url = getSpeechEngine(language,content);
				attrs.src = url;
				audio(parent, node, attrs);
			}
			
			var action = function(parent, node, attrs){
				ui.log("Parse",attrs.fullname);
				var parameters = {};				
				var e = Factory(parent, node, attrs);
				e.prepare(function(){
					var children = node.getElementsByTagName("param");
					for(var i=0;i<children.length;i+=1){
						var c = children[i];
						var name = c.getAttribute("name");
						var value = c.getAttribute("value");
						parameters[name]=value;
					}
					setTimeout(e.onPrepare,TRIGGER);
				});
				e.show(function(){
					ui.log("action.begin",attrs.name);					
					switch(attrs.name){
						case 'milestone':milestones[parameters.name]=Clock.getTime();break;
						case 'seek':fireSeek.apply(this,[1,milestones[parameters.name]]);break;
						case 'stop':fireStop.apply();break;
						case 'reload':fireReload.apply();break;
						case 'pause':firePlay.apply();break;
						case 'resize':ui.resize(parameters.width,parameters.height);break;
						default: ui.log("Action",attrs.name,"Unknown");
					}
				});
				e.hide(function(){/*Nothing*/});
				parent.add(e);
			}
			
			var prefetch = function(parent, node, attrs){
				ui.log("Parse","action");
				var e = Factory(parent, node, attrs);
				e.show(function(){});				
				e.eval(function(){return false;});
				e.onBegin(function(){setTimeout(e.end,1);});				
				e.begin(function(){
					ui.log("prefetch.begin",attrs.name);
					ui.busy(true,"Buffering");
					Clock.pause(); /* prefetch as a temporal element por presentation */
					var type = attrs.type; /*How SMIL 3.0 say what kind of resource is? mime-type? */
					var src = attrs.src;
					if(typeof prefetchs[src] !== 'undefined') return;
					var media;
					if(typeof type == 'undefined' || type.indexOf("image") == 0){
						media = new Image();
						media.id = attrs.id;
						media.src = src;						
						media.onerror = function(){/* Replace error image */
							media.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
						};
						media.onload = function(){ /* The resource is ready */
							ui.prefetch.append(this);
							ui.busy(false);
							Clock.start();
							setTimeout(e.onBegin,1);
						};
					}else 
					if(type == "video/youtube"){
						media = createYTPlayer(attrs, function(){
							ui.busy(false); 
							Clock.start(); 
							setTimeout(e.onBegin,1);
						});						
					}else{ /* video/html5 */
						player = createHTMLMedia("video",attrs, function(){						
							ui.busy(false);
							Clock.start();
							setTimeout(e.onPrepare,1);	
						});
					}
					prefetchs[src]=media;											
				});
				parent.add(e);				
			}
			
			var Factory = function(parent, node, attrs){
				var onPrepare = function(){Notify.fire(attrs.fullname+".onPrepare");};
				var onBegin = function(){Notify.fire(attrs.fullname+".onBegin");};
				var onEnd = function(){Notify.fire(attrs.fullname+".onEnd");};
				
				var that = this;
				var beginTime; /* Clock time of begin method was triggered */				
				var tagName = node.tagName;
				var evalFirsTime = false;
				var eval = function (time,event,control){ /* Eval is most be active */ 
					var isInRange = false;					
					var types = {begin:'time',end:'time',dur:'time'};
					var values = {begin:0,end:0,dur:0};
					
					var atbegin = attrs.begin || 0;
					if(!isNaN(parseInt(atbegin))){
						types.begin = 'time';
						values.begin = parseInt(atbegin);
					}else{
						types.begin = 'event';
						values.begin = atbegin;
					}
					
					var atend = attrs.end || attrs.fullname+".end";
					if(!isNaN(parseInt(atend))){
						types.end = 'time';
						values.end = parseInt(atbegin);
					}else{
						types.end = 'event';
						values.end = atend;
					}
					
					var dur = 0;
					if(typeof attrs.dur != 'undefined'){
						if(!isNaN(parseInt(attrs.dur))){
							types.dur = 'time';
							values.dur = parseInt(attrs.dur);
						}else{
							ui.error(true, attrs.fullname+".eval:error attribute dur='"+attrs.dur+"' is not numeric");
							Clock.pause();
							return false;
						}
					}else if(types.begin=='time' && types.end=='time'){
						dur = values.end - values.begin; 
					}
					
					if(values.dur==0 && !evalFirsTime){
						//ui.log(attrs.fullname+".eval","Rule 0. dur=0",values.begin,values.end,values.dur);
						evalFirsTime=true;
						return true;
					}
					
					if(types.begin=='time' && values.dur>=0){
						var start = beginTime + values.begin*1000;
						var finish = start + values.dur*1000;
						//ui.log(attrs.fullname+".eval","Rule 1. range of time",values.begin,values.end,values.dur,start,finish);
						return	(time>=start && time<=finish);
					}					
					Clock.pause();
					ui.error(attrs.fullname+".eval Rule don't implemented!! ");
					console.log(types);
					console.log(values);
					return false;
				};				
				
				var prepare = function(){ /* Prepare the object for the show */
					setTimeout(onPrepare,TRIGGER);
				};
				
				var begin = function(){					
					beginTime = Clock.getTime();					
					var isActive = false;
					Clock.add(tagName+"-"+attrs.id, function(k, time){						
						if(eval(time, 'tick', that)) {
							if( !isActive ){										
								show.call();								
								isActive = true;
							}
						}else if(isActive){									
							isActive = false;
							hide.call();
							end.call();
						}									
					});
					setTimeout(onBegin,TRIGGER);					
				};
				
				var end = function(){
					setTimeout(onEnd,TRIGGER);
				};
				
				var content = function(){ 
					ui.log(tagName+".content");
					return "replace this content by yours";
				};
				
				var show = function(){
					ui.log(attrs.fullname+".show");
					regions[attrs.region].show();
					regions[attrs.region].setHTML(content());
				};
												
				var hide = function(){
					ui.log(attrs.fullname+".hide");
					var fill = attrs.fill || 'remove';
					if(fill == 'remove'){
						regions[attrs.region].hide();
						regions[attrs.region].setHTML("");
					}
				};
				
				return ({
					attrs:attrs,
					eval:function(fn){(fn)?(eval = fn):(eval.call());},
					show:function(fn){(fn)?(show = fn):(show.call());},
					hide:function(fn){(fn)?(hide = fn):(hide.call());},					
					content:function(fn){(fn)?(content = fn):(content.call());},
					prepare:function(fn){if(fn) prepare = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".prepare");prepare.call();}},			
					begin:function(fn){if(fn) begin = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".begin");begin.call();}},
					end:function(fn){if(fn) end = fn; else{Notify.fire(attrs.fullname+".end");end.call();}},			
					onPrepare:function(fn){if(fn) onPrepare = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".onPrepare");onPrepare.call();}},
					onBegin:function(fn){if(fn) onBegin = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".onBegin");onBegin.call(); }},
					onEnd:function(fn){if(fn) onEnd = fn; else{Notify.fire(attrs.tagName+"@"+attrs.id+".onEnd");onEnd.call(); }}
				});
			};
			
			var question = function (parent, node, attrs){ 
				ui.log("Parse","text");
				var e = Factory(parent, node, attrs);
				e.content(function (){return getText(node);});
				parent.add(e);
			}
			
			var video = function (parent, node, attrs){	
				ui.log("Parse",attrs.fullname);								
				var player;			
				var	canplay = function(){
					ui.log("HTML5 video Created");					
				};
				var e = Factory(parent, node, attrs);
				
				e.prepare(function(){
					Notify.fire(attrs.fullname+".prepare");
					ui.busy(true,"Buffering");
					Clock.pause();	
					if(attrs.type=="youtube/video"){
						player = createYTPlayer(attrs, function(){							
							prefetchs[attrs.src] = player;							
							var r = regions[attrs.region];
							var w = parseInt(r.getComputedStyle("width"),10);
							var h =  parseInt(r.getComputedStyle("height"),10);							
							var uip = player.ui();
							ui.setStyle(uip,{width:"100%", height:"100%", top:0, left:0});
							ui.busy(false);
							Clock.start();
							setTimeout(e.onPrepare,TRIGGER);
						});
					}
					else{ /* HTML5 Video */
						ui.log("info","Creating htm5 video");							
						busy(true, "Preparing");
						player = createHTMLMedia("video",attrs, canplay);
						ui.busy(false);
						Clock.start();
						setTimeout(e.onPrepare,TRIGGER);							
					}							
				});				
				var isRunning = false;
				e.show(function(){
					Notify.fire(attrs.fullname+".show");
					ui.log(attrs.fullname+".show");
					var clipBegin = attrs.clipBegin || 0;
					var vClock = (function(){						
						var beginTime = Clock.getTime();
						var trys = 5;
						var isChecking = false;
						var isEnable = true;
						var check = function(){
							if(isRunning==false){
								try{ player.play();	}catch(err){ ui.log("video.play:error",err); }
								isRunning=true;
							}
							try{
								var state = player.state();
								var cTime = player.getCurrentTime();
								var delta = (cTime>clipBegin)?(cTime-clipBegin):0;								
								//ui.log("video.clock.check",player.state(),beginTime,cTime,delta);
								if(state==1){
									Clock.setTime(beginTime+(delta*1000));								
								}
							}catch(err){
								console.log("video.clock.error "+err);
								console.log(player);
								ui.log("video.clock.error",err);
								trys+=1;
							}
							if(trys>0 && isEnable){
								setTimeout(check, 250);	
							}else{
								isChecking=false;
								/*
								ui.log("video.clock.error.timeout");								
								Clock.setSource(); 
								if(model.length()!=0){									
									Clock.start();
								}
								ui.busy(false);
								*/
							}
						};						
						return ({
							enable:function(e){isEnable=e;},
							start:function(){
								if(!isChecking){
									isChecking = true;
									setTimeout(check, 1);
								}
								player.play();								
							},
							stop:function(){
								player.pause();	
							},
							seek:function(offset){
								player.seek(offset);
							}
						});
					})();
					
					var lastEvt;		
					player.add(function (evt){
						evt	= evt || player.state();
						var msg = ["unstarted","stop","runnning","paused","buffering","unknown","Video Cued"];
						if(lastEvt!=evt){ 
							Notify.fire(attrs.fullname+".state\t"+msg[evt+1]); 
							lastEvt = evt;
						}
						
						if(evt==0){
							ui.busy(false); 
							Clock.setSource(); /*Retorn control to System */
							if(model.length()!=0){									
								Clock.start();
							}
							return;
						}
						
						if(evt!=1){ ui.busy(true,msg[evt+1]); }
						else{ ui.busy(false); }
						
						if(isRunning==false){
							player.seekTo(clipBegin);
							isRunning=true;
							vClock.start();
						}
					});
					try{
						player.play();
					}catch(err){
						ui.log(attrs.fullname+".show.player.play");
					}
					
					regions[attrs.region].setHTML(player.ui());
					regions[attrs.region].show();
					Clock.setSource(vClock);
					
				});
				e.hide(function(){					
					ui.log(attrs.fullname+".hide");
					var fill = attrs.fill || 'remove';
					if(fill == 'remove'){
						regions[attrs.region].setStyle("display","none");
						regions[attrs.region].setHTML("");
					}
					Clock.setSource();
					Clock.start();
				});
				parent.add(e);
			};
			
			var text = function (parent, node, attrs){
				ui.log("Parse",attrs.fullname);
				var e = Factory(parent, node, attrs);
				e.content(function (){return getText(node);});
				parent.add(e);
			}
			
			var img = function (parent, node, attrs){
				ui.log("Parse","img");
				var e = Factory(parent, node, attrs);				
				var img = new Image();				
				e.prepare(function(){				
					ui.log("img.prepare");
					ui.busy(true,"Buffering");
					Clock.pause();	
					img.src = attrs.src;			
					var fit = attrs.fit || 'fill';
					var r = regions[attrs.region];
					r.setStyle("overflow","hidden");
					var w = parseInt(r.getComputedStyle("width"),10);
					var h =  parseInt(r.getComputedStyle("height"),10);					
					switch(fit){
						case 'meet':
							var min = Math.min(w,h);
							w = (min==w)?w:min;
							h = (min==h)?h:min;
							img.width = w;
							img.height = h;
							break;
						case 'hidden':							
							break;
						case 'fill':
						default:
							img.width = w;
							img.height = h;
							
							break;
					}
					img.onerror = function(){/* Replace error image */
						img.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
					};
					img.onload = function(){ /* The resource is ready */												
						//busy(500); /* simular delay */
						ui.log("img.prepare","Ready!");
						ui.busy(false);
						Clock.start();
						setTimeout(e.onPrepare,TRIGGER);
					};					
				});				
				e.content(function (){ui.log("img.content"); return img;});
				parent.add(e);				
			}
			
			var parseChildren = function (node, parent){
				var children = node.childNodes;
				for(var i=0;i<children.length;i+=1){
					var c = children[i];
					if (c.nodeType==1){ /* element */
						var tagName = c.tagName;
						if(typeof Parser[tagName] !== 'undefined'){					
							Parser[tagName].apply(that, [parent, c, getAttributes(c)]);
						}else{
							ui.log("Undefined Parser to "+tagName);
						}
					}
				}
			}
			
			var seq = function(parent, node, attrs){
				ui.log("Parse",attrs.fullname);				
				/*attrs: begin, end, dur, fill, fillDefault, repeatCount, repeatDur, endsync, min, max*/
				var queue = Queue(parent, node, attrs);
				queue.prepare(function(){
					ui.log(attrs.fullname,"#Tasks",queue.length());					
					var onPrepare = function (i, element){										
						return (function(){
							ui.log(attrs.fullname,"Task."+element.attrs.fullname,".prepared");									
							element.begin.call();
						});
					}					
					var onEnd = function(i, element){						
						return (function (){
							var next = i+1;								
							ui.log(attrs.fullname,"Task-"+element.attrs.fullname,".end");
							if(next==queue.length()){
								ui.log(attrs.fullname,"LastTask",".end");
								setTimeout(queue.onEnd,TRIGGER);
							}else{
								queue.get(next).prepare.call();
							}
						});
					};				
					for(var i=0; i<queue.length(); i+=1){
						var element = queue.get(i);	
						element.onPrepare(onPrepare(i, element));
						element.onEnd(onEnd(i, element));
					}										
					setTimeout(queue.onPrepare,TRIGGER);					
				});
				queue.begin(function(){
					if(queue.length()>0){
						queue.get(0).prepare.call();
					}
					setTimeout(queue.onBegin, TRIGGER);										
				});
				parseChildren(node,queue);	
				if(parent) parent.add(queue);
				return queue;						
			}
			
			var par = function(parent, node, attrs){	
				ui.log("Parse",attrs.fullname);
				/*attrs: begin, end, dur, fill, fillDefault, repeatCount, repeatDur, endsync, min, max*/
				var queue = Queue(parent, node, attrs);
				
				var prepares={};
				var onPrepare = function(j){
					return function(){
						prepares[j]=j;
						var cp = Object.keys(prepares).length;
						ui.log(attrs.fullname,"Task."+j+".onPrepared",cp+"/"+queue.length());
						if(cp==queue.length()){
							ui.log("Par.prepare","Completed");
							setTimeout(queue.onPrepare,TRIGGER);
						}
					}
				};
				
				var begines={};
				var onBegin = function(j){
					return function(){
						begines[j]=j;
						var cb = Object.keys(begines).length;
						ui.log(attrs.fullname,"Task."+j+".onBegin",cb+"/"+queue.length());
						if(cb==queue.length()){
							ui.log("Par.begin","Completed");
							setTimeout(queue.onBegin,TRIGGER);
						}
					}
				};
				
				var finished={};
				var onEnd = function(j){
					return function(){
						finished[j]=j;
						var ce = Object.keys(finished).length;
						ui.log(attrs.fullname,"Task."+j+".onEnd",ce+"/"+queue.length());
						if(ce==queue.length()){
							ui.log("Par.end","Completed");
							setTimeout(queue.onEnd,TRIGGER);
						}
					}
				};	
				
				queue.prepare(function(){
					ui.log(attrs.fullname,"#Tasks",queue.length());				
					for(var i=0; i<queue.length(); i+=1){
						var element = queue.get(i);	
						element.onPrepare(onPrepare(i));
						element.onEnd(onEnd(i));
						element.onBegin(onBegin(i));
						setTimeout(element.prepare,1);
					}
				});
				queue.begin(function(){	
					ui.log(attrs.fullname,"#Tasks",queue.length());						
					if(queue.length()==0){
						setTimeout(queue.onBegin, TRIGGER);
						setTimeout(queue.end, 1);
					}else{
						for(var i=0;i<queue.length();i+=1){
							var e = queue.get(i);	
							setTimeout(e.begin, 1);
						}
					}					
				});
				parseChildren(node,queue);
				parent.add(queue);				
			}	
			
			var switchs = function(parent, node, attrs){
				ui.log("Parse",attrs.fullname);				
				/* eval each child to find a first valid */
				var test = attrs.test || 'undefined';
				var selected;
				
				/*attrs: begin, end, dur, fill, fillDefault, repeatCount, repeatDur, endsync, min, max*/
				var queue = Queue(parent, node, attrs);
				queue.prepare(function(){
					var value = window.SystemInfo[test];					
					for(var i=0; i<queue.length(); i+=1){
						var cAttrs = queue.get(i).attrs;
						if((typeof cAttrs[test]!=='undefined') && cAttrs[test]==value){
							selected = queue.get(i);
							break;
						}
					}
					if(typeof selected == 'undefined'){selected = queue.last();}
					if(typeof selected !== 'undefined') {
						selected.onPrepare(function(){queue.onPrepare();});
						selected.onBegin(function(){queue.onBegin();});
						selected.onEnd(function(){queue.onEnd();});
						selected.prepare.call();
					}					
				});
				queue.begin(function(){	
					if(typeof selected !== 'undefined'){
						selected.begin.call();
					}else{
						setTimeout(queue.onBegin,1);
						setTimeout(queue.onEnd,1);
					}				
				});
				parseChildren(node,queue);
				parent.add(queue);
			} 
			
			return ({
				prefetch:prefetch
				,audio:audio
				,'sml:speach':speach
				,'sml:action':action
				,'sml:question':question
				,video:video
				,text:text
				,img:img
				,seq:seq
				,par:par
				,'switch':switchs
				,xform:xform
			});
		})();
								
		var play = function(){if(model.length()==0){prepareModel();}setTimeout(model.prepare, 1);}	
		
		var firePlay = function(){			
			switch(Clock.state()){
				case 0: /*stoped*/
					Notify.fire("UserControl.play");
					play();
					ui.upatedIcon("#smlearning-play-button",[ICONS.play,ICONS.pause,ICONS.play],["Start","Pause","Start"],1);
					break;
				case 1: /* running */	
					Notify.fire("UserControl.pause");
					Clock.pause();
					ui.upatedIcon("#smlearning-play-button",[ICONS.play,ICONS.pause,ICONS.play],["Start","Pause","Start"],Clock.state());
					break;
				default: /*pause or something else */
					Notify.fire("UserControl.resume");
					Clock.start();
					ui.upatedIcon("#smlearning-play-button",[ICONS.play,ICONS.pause,ICONS.play],["Start","Pause","Start"],Clock.state());
					break;
			}			
		}		
		var fireSeek = function(time){Notify.fire("UserControl.seek\t"+time); Clock.seek(time);}
		var fireReload = function (){Notify.fire("UserControl.reload"); Clock.stop(); playAfterLoad = true; onReload();}		
		var fireStop = function (){Notify.fire("UserControl.stop"); Clock.stop();clean();}
		var fireFullscreen = function(){Notify.fire("UserControl.fullscreen"); ui.toogle();}
		
		ui.addControl("Play",ICONS.play,firePlay,{},{id:"smlearning-play-button"});
		ui.addControl("-30sec",ICONS.backward,function(){fireSeek(-30);});
		ui.addControl("+30sec",ICONS.forward,function(){fireSeek(30);});
		ui.addControl("Reload",ICONS.reload, fireReload);
		ui.addControl("Fullscreen",ICONS.resize,fireFullscreen,{'float':'right'},{id:"smlearning-fullscreen-button"});
		ui.addControl("About",ICONS.about, function(){Notify.fire("UserControl.about"); about(str(metas));}, {'float':'right'});
				
		var onSuccess = function(transactionid, response, ignore){
			if(ignore){return;};			
			if(!response.responseXML){
				Notify.fire("UserControl.load.failed\t"+url);
				ui.error(true, "Load Failed: '"+url+"' is a valid XML file?");
				return;
			}
			Notify.fire("UserControl.load.successed\t"+url);
			root = response.responseXML.documentElement;
			if(playAfterLoad){
				setTimeout(firePlay,1 );
			}
		}
		
		var prepareModel = function(){		
			/*meta are using for send configuration variables */
			var tagMetas = root.getElementsByTagName('meta');
			for(var i=0;i<tagMetas.length;i+=1){
				var meta = tagMetas[i];								
				var name = meta.getAttribute("name");
				var value = meta.getAttribute("content");
				metas[name]=value;
			}
			
			ui.screen.setHTML("");
			
			/*layout*/
			var tagLayout = (root.getElementsByTagName('layout'))[0];
			var children = tagLayout.childNodes;
			for(var i=0;i<children.length;i+=1){
				var layout = children[i];
				if (layout.nodeType != 1) continue;				
				var tagName = layout.tagName;
				var attrs = getAttributes(layout);
				if(tagName=="root-layout"){
					ui.setStyle(ui.screen, attrs); /*global properties to screen */
					ui.right.setStyle("height",attrs.height);
				}else{
					ui.addRegion(attrs);
				}				
			}
						
			/* plugins */
			var plugins = (root.getElementsByTagName('plugins'))[0];
			if(typeof plugins !="undefined"){
				var children = plugins.getElementsByTagName('plugin');
				for(var i=0;i<children.length;i+=1){
					var node = children[i];
					var attrs = getAttributes(node);
					var src = attrs.src;
					var template = attrs.template;
					attrs.icon = attrs.icon || ICONS.test;
					
					var uiplugin = (function(){
						var isVisible = false;
						var plugin; 
						var show = function(){							
							var	controller;				
							transformation(template,src, function(eContent){								
								var loadController = eval(eContent.querySelector("script").textContent);
								var controller = loadController();
								controller.ready(function(){
									plugin = controller.constructor(Notify, ui, Clock, eContent);
									window.plugins = window.plugins|| {};
									window.plugins[attrs.fullname] = plugin;							
									plugin.show();
									isVisible = true;
								});							
							});
						}
						var hide = function(){
							isVisible = false;
							plugin.hide();						
						}
						var toogle = function (){isVisible?hide():show();}
						if(attrs.visible=="true")show();
						return ({
							toogle:toogle,
							show:show,
							hide:hide
						});					
					})();
					if(attrs.visible=="true"){uiplugin.show();}
					ui.addPlugin(attrs.title,attrs.icon,uiplugin.toogle,{'float':'right'});
				}
			}
			
			/* body */
			var body = (root.getElementsByTagName('body'))[0];
			var attrs = getAttributes(body);
			model = Parser.seq(null, body, attrs);
			poster = attrs.poster || ICONS.poster;
			model.onEnd(function(){
				exit();
			});	
			model.onPrepare(function(){
				setTimeout(model.begin, 1);
				
			});
			model.onBegin(function(){
				busy(true,"Start");
				Clock.start();
			});
			setTimeout(print,1,model,0);
			
			attrs.controls = attrs.controls || true;
			if(attrs.controls=="false"){
				ui.controls.hide();
				setTimeout(firePlay,1 );
			}			
		}
		var poster = ICONS.poster;
		var exit = function(){
			var lastTime = Clock.getTime();
			Notify.fire("Document.onEnd");
			clean();
			ui.clock(lastTime);
			ui.upatedIcon("#smlearning-play-button",[ICONS.play],["Start"],0);
			ui.screen.setHTML(ui.img(poster));
		}
		
		var onStart = function(id, args){}		
		var onComplete = function(id, o, args){}		
		var onFailure = function(id, o, args){ui.error(true, "Faild to load "+url+", is the link broken?");}
		
		Y.on('io:start', onStart, Y);
		Y.on('io:complete', onComplete, Y);
		Y.on('io:failure', onFailure, Y);
		Y.on('io:success', onSuccess, Y, false);	
		
		var onLoad = function (_url) {
			Notify.fire("UserControl.load.start\t"+_url);
			url = _url;							 
			Y.io(url+"?seed="+Math.random(),{method: 'POST'});
		}
		
		var clean = function (){
			ids_gen = {};
			ids = {};
			Clock.reset();
			reset(model);
			players = {};
			metas={};
			regions={};
			prefetchs = {};
			model = Queue();
			ui.clean();
		}
		
		var onReload=function(){			
			clean();
			ui.log("Reload",url,"-------------------------------------");
			onLoad(url);
		}
				
		window.Notify = (function(){
			var urlmonitor = "http://al-ozza.ii.uam.es/smlplayer/plugins/monitoring/server.php";
			var send = function(evt){
				var info = [(new Date()).getTime(),parseInt(window.performance.now()),parseInt(Clock.getTime()),evt].join("\t");
				ui.log('<span style="font-weight:bold;color:red">Notify.fire</span>',info);
				var cfg = {
					method:'post'
					,arguments: {success: true}
					,headers: {}
					,data:{data:info}
				};
				Y.io(urlmonitor,cfg);
			}
			return ({
				fire:send
			});
		})();
		
		/*Alive Sensor*/
		(function(){
			var samples = [];
			var aliveTime = 0;
			var alive = function(){
				var delta = window.performance.now()-aliveTime;				
				aliveTime += delta;
				samples.push(delta);
				if(samples.length==10){ /* each 10 samples send a alive notify */
					var avg = 0;
					for(var i=0;i<samples.length;i++)avg+=samples[i];
					avg/=samples.length;
					samples = [];
					Notify.fire("Sensor.alive\t"+avg);
				}
			}
			setInterval(alive, 500);
		})();
		
		
		return ({
			load: onLoad
		});
	});	
   
   Y.MSLPlayer = {
		test: function (id, url){
			url = url;
			var player = WebPlayer(id);
			player.load(url);					
		}
   };   
},
'0.0.1',{requires:['overlay', 'panel', 'node', 'io-base', 'event']});

var getFileContent = function (url, onSuccess){
	YUI().use('io-base', function (Y) {
		/* load XSLTForm */
		(function(){
			console.log(url);
			Y.on('io:success', function(transactionid, response, arguments){			
				if(!response.responseXML){				
					console.log(url+" is a valid XML file?");
					return;
				}							
				onSuccess(response.responseXML);
			}, Y);						
			var request = Y.io(url);
		})();
	});	
}

var serialize = function (formObject){
	YUI().use("io-form","node", function(Y){ 		
		var cfg = {
            method: 'POST',
            form: {id:  formObject,useDisabled: false}
        };
		function complete(id, o, args) {
		  var data = o.responseText; 
		  console.log(data);
		};
		Y.on('io:complete', complete, Y);
		var request = Y.io("mirror.php", cfg);
	});
};

var QueryParameters = function () {
  var query_string = {};
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i=0;i<vars.length;i++) {
	var pair = vars[i].split("=");
		// If first entry with this name
	if (typeof query_string[pair[0]] === "undefined") {
	  query_string[pair[0]] = pair[1];
		// If second entry with this name
	} else if (typeof query_string[pair[0]] === "string") {
	  var arr = [ query_string[pair[0]], pair[1] ];
	  query_string[pair[0]] = arr;
		// If third or later entry with this name
	} else {
	  query_string[pair[0]].push(pair[1]);
	}
  } 
	return query_string;
} ();	