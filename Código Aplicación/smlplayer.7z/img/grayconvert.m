    [filename, pathname] = uigetfile('*.png', 'Image to Convert');
    [A map alpha] = imread(strcat(pathname,filename));
    I = rgb2gray(A);
    imshow(I);
    imwrite(I, strcat(pathname, 'gray-',filename), 'Alpha', alpha);

