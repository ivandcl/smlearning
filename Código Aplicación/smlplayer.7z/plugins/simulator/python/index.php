<!DOCTYPE>
<html>
	<head>
		<title>SMLPlayer - ivandcl(at)gmail.com</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="description" content="SMLPlayer" />
		<meta name="keywords" content="Multimedia, education" />
		<meta name="robots" content="index,follow" />
		<link rel="stylesheet" type="text/css" href="sql.css" />
		<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>		
		<link rel="stylesheet" href="lib/codemirror.css" />
		<script src="lib/codemirror.js"></script>
		<script src="mode/python/python.js"></script>
		<style>	
		nav{	
				border-radius: 5px;			
				position:relative;
				background:gold;		
				border: solid 1px goldenrod;
				padding: 4px 5px 5px;
				margin:0px;
				font-size:1em;
				color:#333;
				font-size:1.1em;text-align:center;
			}
		h1{ display:inline;}	
		nav a {float:right;}
		#main{
				background-color: rgba(255,255,255,0.8);
				box-shadow: 0 0 1px 1px rgba(255,255,0,0.4);
				border-radius: 3px;
				color:#333;
				margin:5px;
				padding:5px;background:#fff;text-align:left; 
				border: solid 1px #ccc;font-weight: bold;
				font: 11px "lucida grande",tahoma,verdana,arial,sans-serif;}
		.CodeMirror{height:100px;border:1px solid #ccc;}
		#sqlcode-result{
			overflow-y:scroll;
			max-height:300px;
			margin:0px;padding:0px;
			width:100%;
			border:1px solid #ccc;
		}#sqlcode-result table{
			width:100%;
			font-family: arial, sans-serif;
			font-size: 1em;
			font-weight: normal;
			margin:0px;padding:0px;
		}#sqlcode-result tr:nth-child(odd){ background-color:#ffffff; 
		}#sqlcode-result tr:nth-child(even){ background-color:#e5e5e5; }
		#sqlcode-result td{
			vertical-align:middle;
			text-align:center;			
			color:#666;
		}#sqlcode-result tr th{
			background-color:gold;
			padding:3px;
			color:#333;}
		.error{
			margin:5px;
			padding:5px;
			background-color:#ffcccc;}
		.success h1{
			color: green;}
		.success{
			margin:5px;
			padding:5px;
			color: green;
			background-color:#eeffcc;}
	</style>
	</head>	
	<body>
		<script>
			$(function(){
				var mime = 'text/x-python';
				window.editor = CodeMirror.fromTextArea(document.getElementById('code'), {
					mode: mime,
					indentWithTabs: true,
					smartIndent: true,
					lineNumbers: true,
					matchBrackets : true,
					autofocus: true
				});	
				var query = window.editor.getValue();
				var schema;
				$("#mode").click(function(){
					$(this).toggleClass("schema");
					if($(this).is(".schema")){
						$(this).html('<img title="Schema" src="schema.png"/>');
						window.editor.setValue(query);
					}else{
						query = window.editor.getValue();
						$(this).html('<img title="Query" src="query.png"/>');
						if(typeof schema == 'undefined'){
							$.get("server.php",function(data){window.editor.setValue(data);schema=data;});
						}else{	
							window.editor.setValue(schema);
						}
					}
					return false;
				}).click();	
				$("#sqlcode-form").submit(function(){
					var mode = $("#mode").is(".schema")?"query":"schema";
					$.post("server.php?action="+mode,{code:window.editor.getValue()},function(data){
						$("#sqlcode-result").html(data);
					});
					return false;
				});
			});
		</script>
		<div id="main">
			<nav>
				<h1>Python</h1><a href="#" id="mode"></a>
			</nav>
			<article>	
				<section>			
					<form id="sqlcode-form">
						<textarea id="code" name="sql"><?php echo file_get_contents("sample.py");?></textarea>
						<div style="text-align:right;">
							<input id="btsubmit" type="submit" value="Execute">
						</div>
					</form>	
				</section>	
				<pre id="sqlcode-result"></pre>					
			</article>
			<footer>
				ivandcl - 2013 &copy;
			</footer>
		</div>
	</body>
</html>