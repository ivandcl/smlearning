﻿#Python sample code
from time import time

def fact(n):
 return 1 if n<2 else n*fact(n-1)

for x in xrange(10):
 print x,fact(x),time()