def fact(n):
 return 1 if n<2 else n*fact(n-1)

print fact(10),10*9*8*7*6*5*4*3*2