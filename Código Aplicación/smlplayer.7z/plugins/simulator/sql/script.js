var newPlugin = function (Notify, ui, Clock, eContent,idform){	
	var query;
	var keyevents = [];
	var lastkeyevent=0;
	
	var show = function (){	
		Notify.fire("plugin-simulator.show");
		ui.right.setHTML(eContent);
		ui.right.show();	
		var mime = 'text/x-mariadb';		
		window.editor = CodeMirror.fromTextArea($(idform+" textarea").get(0), {
			mode: mime,
			indentWithTabs: true,
			smartIndent: true,
			lineNumbers: true,
			matchBrackets : true,
			autofocus: true,
			onKeyEvent: function(editor, event){
				event = $.event.fix(event);
				var enterKeyHasBeenPressed = event.type == "keydown";    
				if(enterKeyHasBeenPressed ){
					var t = parseInt(window.performance.now(),10);
					var delta = t-lastkeyevent;
					lastkeyevent = t;
					keyevents.push(delta+";"+event.which); 
				}				
			}
		});	
		query = window.editor.getValue();
		var schema;
		$("#mode").click(function(){
			$(this).toggleClass("schema");
			if($(this).is(".schema")){
				$(this).html('<img title="Schema" src="http://al-ozza.ii.uam.es/smlplayer/plugins/simulator/sql/schema.png"/>');
				window.editor.setValue(query);
			}else{
				query = window.editor.getValue();
				$(this).html('<img title="Query" src="http://al-ozza.ii.uam.es/smlplayer/plugins/simulator/sql/query.png"/>');
				if(typeof schema == 'undefined'){
					$.get($(idform).attr("action"),function(data){window.editor.setValue(data);schema=data;});
				}else{	
					window.editor.setValue(schema);
				}
			}
			return false;
		}).click();	
		$(idform).submit(function(){
			var mode = $("#mode").is(".schema")?"query":"schema";
			$.post($(this).attr("action")+"?action="+mode,{sql:window.editor.getValue()},function(data){
				$("#sqlcode-result").html(data);
			});
			Notify.fire("plugin-simulator.send\t"+keyevents.join("\t"));
			keyevents = [];
			return false;
		});
	}	
	var hide = function(){
		Notify.fire("plugin-simulator.hide");
		ui.right.hide();
	}
	return ({
		show:show,
		hide:hide
	});
};