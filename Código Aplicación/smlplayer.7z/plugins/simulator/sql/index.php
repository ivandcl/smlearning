<!DOCTYPE>
<html>
	<head>
		<title>SMLPlayer - ivandcl(at)gmail.com</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="description" content="SMLPlayer" />
		<meta name="keywords" content="Multimedia, education" />
		<meta name="robots" content="index,follow" />
		<link rel="stylesheet" type="text/css" href="sql.css" />
		<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>		
		<link rel="stylesheet" href="lib/codemirror.css" />
		<script src="lib/codemirror.js"></script>
		<script src="mode/sql/sql.js"></script>
		<style>	
		nav{	
				border-radius: 5px;			
				position:relative;
				background:gold;		
				border: solid 1px goldenrod;
				padding: 4px 5px 5px;
				margin:0px;
				font-size:1em;
				color:#333;
				font-size:1.1em;text-align:center;
			}
		h1{ display:inline;}	
		nav a {float:right;}
		#main{
				background-color: rgba(255,255,255,0.8);
				box-shadow: 0 0 1px 1px rgba(255,255,0,0.4);
				border-radius: 3px;
				color:#333;
				margin:5px;
				padding:5px;background:#fff;text-align:left; 
				border: solid 1px #ccc;font-weight: bold;
				font: 11px "lucida grande",tahoma,verdana,arial,sans-serif;}
		.CodeMirror{height:100px;border:1px solid #ccc;}
		#sqlcode-result{
			overflow-y:scroll;
			max-height:300px;
			margin:0px;padding:0px;
			width:100%;
			border:1px solid #ccc;
		}#sqlcode-result table{
			width:100%;
			font-family: arial, sans-serif;
			font-size: 1em;
			font-weight: normal;
			margin:0px;padding:0px;
		}#sqlcode-result tr:nth-child(odd){ background-color:#ffffff; 
		}#sqlcode-result tr:nth-child(even){ background-color:#e5e5e5; }
		#sqlcode-result td{
			vertical-align:middle;
			text-align:center;			
			color:#666;
		}#sqlcode-result tr th{
			background-color:gold;
			padding:3px;
			color:#333;}
		.error{
			margin:5px;
			padding:5px;
			background-color:#ffcccc;}
		.success h1{
			color: green;}
		.success{
			margin:5px;
			padding:5px;
			color: green;
			background-color:#eeffcc;}
	</style>
	</head>	
	<body>
		<script>/*
			$(function(){
				var mime = 'text/x-mariadb';
				window.editor = CodeMirror.fromTextArea(document.getElementById('code'), {
					mode: mime,
					indentWithTabs: true,
					smartIndent: true,
					lineNumbers: true,
					matchBrackets : true,
					autofocus: true
				});	
				var query = window.editor.getValue();
				var schema;
				$("#mode").click(function(){
					$(this).toggleClass("schema");
					if($(this).is(".schema")){
						$(this).html('<img title="Schema" src="schema.png"/>');
						window.editor.setValue(query);
					}else{
						query = window.editor.getValue();
						$(this).html('<img title="Query" src="query.png"/>');
						if(typeof schema == 'undefined'){
							$.get("server.php",function(data){window.editor.setValue(data);schema=data;});
						}else{	
							window.editor.setValue(schema);
						}
					}
					return false;
				}).click();	
				$("#sqlcode-form").submit(function(){
					var mode = $("#mode").is(".schema")?"query":"schema";
					$.post("server.php?action="+mode,{sql:window.editor.getValue()},function(data){
						$("#sqlcode-result").html(data);
					});
					return false;
				});
			});*/
			eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('$(4(){9 j=\'J/x-I\';2.1=H.G(F.A(\'z\'),{5:j,y:3,w:3,u:3,t:3,E:3});9 7=2.1.b();9 0;$("#5").n(4(){$(8).s("0");f($(8).p(".0")){$(8).a(\'<i h="v" g="0.e"/>\');2.1.c(7)}o{7=2.1.b();$(8).a(\'<i h="B" g="7.e"/>\');f(C 0==\'D\'){$.r("m.l",4(6){2.1.c(6);0=6})}o{2.1.c(0)}}d q}).n();$("#k-K").L(4(){9 5=$("#5").p(".0")?"7":"0";$.M("m.l?N="+5,{O:2.1.b()},4(6){$("#k-P").a(6)});d q})});',52,52,'schema|editor|window|true|function|mode|data|query|this|var|html|getValue|setValue|return|png|if|src|title|img|mime|sqlcode|php|server|click|else|is|false|get|toggleClass|matchBrackets|lineNumbers|Schema|smartIndent||indentWithTabs|code|getElementById|Query|typeof|undefined|autofocus|document|fromTextArea|CodeMirror|mariadb|text|form|submit|post|action|sql|result'.split('|'),0,{}))
		</script>
		<div id="main">
			<nav>
				<h1>SQL - Postgres</h1><a href="#" id="mode"></a>
			</nav>
			<article>	
				<section>			
					<form id="sqlcode-form">
						<textarea id="code" name="sql"><?php echo file_get_contents("query.sql");?></textarea>
						<div style="text-align:right;">
							<input id="btsubmit" type="submit" value="Execute">
						</div>
					</form>	
				</section>	
				<section id="sqlcode-result"></section>					
			</article>
			<footer>
				ivandcl - 2013 &copy;
			</footer>
		</div>
	</body>
</html>