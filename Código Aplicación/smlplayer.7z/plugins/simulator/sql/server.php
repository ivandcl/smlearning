<?php session_start();
error_reporting(E_ERROR);
	if(!isset($_GET['action'])){
		echo file_get_contents("world.sql");
		exit;
	}
	$dbname = "db".session_id();
	if(!isset($_SESSION['dbname'])){
		$dbconn = pg_connect("host=127.0.0.1 port=5433 user=postgres password=dell5100") or die('Could not connect: ' . pg_last_error());	
		pg_query($dbconn, "CREATE DATABASE $dbname");
		pg_query($dbconn, "drop schema public cascade; create schema public;");	
		pg_query($dbconn, file_get_contents("world.sql"));	
		pg_close($dbconn);
		$_SESSION['dbname'] = $dbname;		
	}
	
	if(isset($_GET['action']) && isset($_POST['sql'])){
		$dbconn = pg_connect("host=127.0.0.1 port=5433 dbname=$dbname user=postgres password=dell5100") or die('Could not connect: ' . pg_last_error());		
		if(!$dbconn){echo pg_last_error($dbconn); exit;};
		switch($_GET['action']){
			case "schema":
				pg_query($dbconn, "drop schema public cascade; create schema public;");
				$result = pg_query($dbconn, $_POST['sql']);				
				$err= pg_last_error($dbconn);
				if(empty($err)) 
					echo '<div class="success"><h1>Success:</h1><br/>Number of rows affected '.pg_affected_rows($result).'<div>';
				else 
					echo '<div class="error"><h1>Error:</h1><br/>'.$err.'<div>';				
				break;
			case "query":
				try{
					$result = pg_query($_POST['sql']);
					$err= pg_last_error($dbconn);
					if(empty($err)) 
						table_create($result);
					else 
						echo '<div class="error"><h1>Error:</h1><br/>'.$err.'<div>';
				}catch(Exception $err){
					echo $err;
				}
				
				break;			
		}
		pg_close($dbconn);
	}
	function table_create($result){
		$numrows = pg_num_rows($result);
		$fnum = pg_num_fields($result);

		echo "<table>";
		echo "<tr>";

		for ($x = 0; $x < $fnum; $x++) {
			echo "<th>";
			echo strtoupper(pg_field_name($result, $x));
			echo "</th>";
		}

		echo "</tr>";

		for ($i = 0; $i < $numrows; $i++) {
			$row = pg_fetch_object($result, $i);
			echo "<tr align='center'>";
			for ($x = 0; $x < $fnum; $x++) {
		$fieldname = pg_field_name($result, $x);
		echo "<td>";
		echo $row->$fieldname;
		echo "</td>";
			}
			echo"</tr>";
		}
		echo "</table>";
		
		return 0;
	}
?>
