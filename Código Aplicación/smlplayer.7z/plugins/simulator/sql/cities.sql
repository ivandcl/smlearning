CREATE TABLE City (
  "ID" integer,
  "Name" char(35),
  "CountryCode" char(3),
  "District" char(20),
  "Population" integer
);
INSERT INTO City VALUES (1,'Kabul','AFG','Kabol',1780000);