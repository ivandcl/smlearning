<?php
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
	header('Content-type: text/json');
	header('Content-type: application/json');
	
	function guid(){
		if (function_exists('com_create_guid') === true){return trim(com_create_guid(), '{}');}
		return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
	}
	
	function startsWith($haystack, $needle){
		return $needle === "" || strpos($haystack, $needle) === 0;
	}
	
	$headers = apache_request_headers();
	$hdata = [];
	foreach ($headers as $header => $value) {
		if(startsWith($header,"social-"))
		$hdata[$header]=$value;
	}
	
	
	
	$hdata['social-server-time']=time();	
	$session = isset($_GET['id'])?$_GET['id']:(isset($hdata['social-session'])?$hdata['social-session']:guid());	
	header('social-session: '.$session);
	
	$filename = './sessions/social-chat-'.$session.'.txt';
	$data = Array();
	
	if(isset($hdata['social-update-lasttime']) && $hdata['social-update-lasttime']=="".filemtime($filename) ) 
		exit; /* there isn't something new */
	
	if(file_exists($filename)){
		$data = json_decode(file_get_contents($filename));
	}
	
	if(!empty($_POST['message'])){		
		$msg = [];
		foreach ($hdata as $header => $value) {	$msg[$header] = $value;}
		$msg["content"] = $_POST['message'];
		$data[] = $msg;
		 /* create a stream context telling PHP to overwrite the file */ 
		$options = array('ftp' => array('overwrite' => true)); 
		$stream = stream_context_create($options); 
		file_put_contents($filename, json_encode($data), 0,$stream);
		header('social-transaction-id: '.$hdata['social-server-time']);			
	}	
	header('social-update-lasttime:'.filemtime($filename));
	echo json_encode($data);	
?>