(function($) {
    $.fn.goTo = function() {
        $('html, body').animate({
            scrollTop: $(this).offset().top + 'px'
        }, 'fast');
        return this; // for chaining...
    }
})(jQuery);

navigator.getMedia = ( navigator.getUserMedia ||
                       navigator.webkitGetUserMedia ||
                       navigator.mozGetUserMedia ||
                       navigator.msGetUserMedia);
					   
var newPlugin = function (Notify, ui, Clock, eContent,idform){

	$.getScript('http://al-ozza.ii.uam.es/smlplayer/plugins/social/jquery.scrollTo-min.js');
			
	var form;	
	var synchronize;
	var social;
	
	window.SystemInfo = window.SystemInfo || {};
	window.SystemInfo.username = window.SystemInfo.username || "User-"+parseInt(Math.random()*1000);
	
	$(".messages-area").css("height", (parseInt(ui.right.getStyle("height"),10)-25)+"px");
	Clock.add("social-plugin"+idform, function(k, time){
		update();	
	});
	
	var canvas;
	var video;
			
	function webcam(){
		// Not showing vendor prefixes.		
		navigator.getMedia({video: true, audio: false}, function(localMediaStream) {
			canvas = $("<canvas height=\"128\" width=\"128\" style=\"display:none\"/>").appendTo($(idform+"-title")).get(0);	
			var bc = canvas.getContext('2d');			
			video = $("<video height=\"128\" width=\"128\" style=\"display:none;float:left;clear:right;position:relative\"/>").appendTo($(idform+"-title")).get(0);
			video.autoplay=true;
			video.src = window.URL.createObjectURL(localMediaStream);	
			video.addEventListener('play', function(){
				var refresh = function(){
					bc.drawImage(video,0,0,128,128);					
					setTimeout(refresh, 3000);
				}
				setTimeout(refresh, 1);
			},false);			
		});
	}

	/*webcam();*/
	var socialUpdateLasttime=0;	
	window.performance = window.performance || {};
	window.performance.now = window.performance.now || function(){return (new Date()).getTime();};
	(function(){
		var update = function(){				
			try{
				var url = form.attr("action")+(window.SystemInfo[form.data("suffix")] || "");
				$.ajax({
					url:url,
					method:'post',
					data:{},
					headers: {"social-update-lasttime":socialUpdateLasttime, "social-window-time":window.performance.now(), "social-local-time":Clock.getTime(),"social-username": window.SystemInfo.username,"social-session":window.SystemInfo['social-session']},
					success:function (data, textStatus, jqXHR){
						display(data);
						socialUpdateLasttime = jqXHR.getResponseHeader("social-update-lasttime");
						window.SystemInfo['social-session']=jqXHR.getResponseHeader("social-session");									
					}
				});	
				setTimeout(update, 5000);
			}catch(err){
				ui.log("Plugin-social-Error",err);
			}
		}
		setTimeout(update,1);
	})();
	
	var Color = (function(){
		return {
			rnd:function(){ 
				return 'rgb('+ (Math.floor(Math.random() * 156)) + ',' + (Math.floor(Math.random() * 156)) + ','		+ (Math.floor(Math.random() * 156)) + ')';
			}
		};			
	})();

	var hide = function(){
		Notify.fire("plugin-social.hide");
		ui.right.hide();
	};				
		
	var update = function(){	
		$(".messages-area li").removeClass("active");
		if(!synchronize.is(".active")) return;
		var cls = Math.ceil(Clock.getTime()/5000)*5;		
		form.find(".t"+cls).addClass("active");
		try{$(".messages-area").scrollTo(".t"+cls);}catch(err){}
	}
	
	var repaint = function(c){
		if(!c) return;
		c.sort(function (a, b){
			return parseInt(b['social-server-time'],10)-parseInt(a['social-server-time'],10);
		});
		c.sort(function (a, b){
			return parseInt(a['social-local-time'],10)-parseInt(b['social-local-time'],10);
		});
		var isSocial = social.is(".active");
		var str="";
		for(var i=0;i < c.length; i+=1){
			var row = c[i];
			if(!isSocial){
				if(row['social-username']!=window.SystemInfo.username)
					continue;
			}
			var local = ui.t2s(row['social-local-time']);
			var color = "black";
			if(typeof authors[row['social-username']]!='undefined'){
				color=authors[row['social-username']];
			}else{
				color = Color.rnd();
				authors[row['social-username']]=color;
			}
			var cls = Math.ceil(row['social-local-time']/5000)*5;
			/*
			var urlface =  (typeof row['social-user-face']!="undefined")?row['social-user-face']:"img/nopicture32.png";
			var ico = '<img width="32" height="32" src="'+urlface+'"/>';
			*/
			var ico = "";
			str += "<li style=\"clear:both;\" class=\"t"+cls+"\" id=\"m"+row['social-server-time']+"\"> <span class=\"time\">"+local+"</span> <span style=\"float:right;\">"+ico+"</span> <span style=\"color:"+color+"\" class=\"author\">"+row['social-username']+"</span> "+row['content']+"</li>";
		}
		form.find(".messages").html(str);
	}
	
	var data;
	var sortby='social-local-time';
	var authors = {};
	var display =function(c,jqXHR){
		if(!c){
			form.find(".messages").html("<li>Ups! - Server connection failed</li>");
			return;
		}		
		repaint(c);
		if(jqXHR){			
			var id =  "m"+jqXHR.getResponseHeader("social-transaction-id");			
			$(".messages-area").scrollTo("#"+id);
			ui.hightligth(id);			
		}else{
			update();
		}
		data = c;
	}
	
	var keyevents = [];
	var lastkeyevent=0;
	var show = function(){
		Notify.fire("plugin-social.show");
		ui.right.setHTML(eContent);
		ui.right.show();
		form = $(idform);
		form.submit(function (){try{process($(this));}catch(err){console.log(err);} return false;});	
		form.find(".messages-area").css("height", (parseInt(ui.right.getStyle("height"),10)-30)+"px");
		synchronize = $('<a style="padding:0px;inline-block;" href="#"></a>').appendTo($(idform+"-title")).css("float","left");
		synchronize.click(function(){			
			$(this).toggleClass("active");
			if($(this).is(".active")){
				$(this).html('<img title="No synchronize" src="http://al-ozza.ii.uam.es/smlplayer/img/active.png"/>');				
			}else{
				$(this).html('<img title="Synchronize" src="http://al-ozza.ii.uam.es/smlplayer/img/inactive.png"/>');
			}
			update();
			Notify.fire("plugin-social.syn:"+($(this).is(".active")));
		});
		synchronize.click();
		
		social = $('<a style="padding:0px;inline-block;" href="#"></a>').appendTo($(idform+"-title")).css("float","right");
		social.click(function(){			
			$(this).toggleClass("active");
			if($(this).is(".active")){
				$(this).html('<img title="Filter just me!" src="http://al-ozza.ii.uam.es/smlplayer/img/group.png"/>');				
			}else{
				$(this).html('<img title="Everybody" src="http://al-ozza.ii.uam.es/smlplayer/img/individual.png"/>');
			}
			repaint(data);
			Notify.fire("plugin-social.social:"+($(this).is(".active")));
		});
		social.click();
		
		$(idform+"-inputbox").keydown(function(event) {
			var t = parseInt(window.performance.now(),10);
			var delta = t-lastkeyevent;
			lastkeyevent = t;
			keyevents.push(delta+";"+event.which);
		});
	};	
	
	var not = function(value){return value?false:true;};	
	var element;
	var process = function(form){
		Notify.fire("plugin-social.send\t"+form.serialize()+"\t"+keyevents.join("\t"));
		keyevents = [];
		var url = form.attr("action")+(window.SystemInfo[form.data("suffix")] || "");
		$.ajax({
			url:url
			,method:'post'
			,data:form.serialize()
			,headers: {				
				/*"social-user-face":canvas?canvas.toDataURL("image/jpeg"):""*/
				"social-window-time":window.performance.now()
				,"social-local-time":Clock.getTime()
				,"social-username": window.SystemInfo.username
				,"social-session":window.SystemInfo['social-session']
			}
			,success:function (data, textStatus, jqXHR){
				display(data,jqXHR);
				socialUpdateLasttime = jqXHR.getResponseHeader("social-update-lasttime");
				window.SystemInfo['social-session']=jqXHR.getResponseHeader("social-session");
				form.find(".inputbox").val("");
			}
		});
		return false;
	}				
	return ({
		show:show,
		hide:hide
	});
}	