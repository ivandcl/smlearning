<?php
ini_set('display_errors', '1');
error_reporting(E_ALL);
session_start();

$filename = './logs/session-id-'.session_id().'.txt';
if(!file_exists($filename)){
	$ourFileHandle = fopen($filename, 'w') or die("Report cann't be saved :(");
	fwrite($ourFileHandle, "HTTP_USER_AGENT:".$_SERVER['HTTP_USER_AGENT']."\n");
	fwrite($ourFileHandle, "REMOTE_ADDR:".$_SERVER['REMOTE_ADDR']."\n");
	fwrite($ourFileHandle, "REQUEST_TIME:".$_SERVER['REQUEST_TIME']."\n");	
	fwrite($ourFileHandle, "DATA:\n");
	fclose($ourFileHandle);
}
header("Content-Type:text/plain");
if(isset($_POST['data'])){
	if (is_writable($filename)) {
		$handle = fopen($filename, 'a') or die("Report cann't be saved :(");
		list($usec, $sec) = explode(" ", microtime());
		$stamp = ($sec+$usec)*1000;
		fwrite($handle, "\n".$stamp."\t".$_POST['data']);
		fclose($handle);
	}
}else{
	print_r(file_get_contents($filename));
}
?>