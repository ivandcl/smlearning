<?php
	ini_set('display_errors', '1');
	error_reporting(E_ALL);
	print_r($_GET);
	//print_r(passthru ('python nlp.py > o.txt', $retval));
	system ('python nlp.py', $retval);
	print __FILE__;
	//file_get_contents(__FILE__);
?>