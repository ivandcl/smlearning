#use nltk library to calc metrics related with user interaction 
#ivandcl -2013
import nltk
def nlp():	
	sentence = """The 1938 Home Nations Championship was the thirty-fourth series of the rugby union Home Nations Championship. Including the previous incarnations as the Five Nations, and prior to that, the Home Nations, this was the fifty-first series of the northern hemisphere rugby union championship. Six matches were played between 15 January and 19 March. It was contested by England, Ireland, Scotland and Wales."""
	wordlist = nltk.word_tokenize(sentence)
	frecuency = nltk.FreqDist(wordlist)	
	f = open('metrics.txt','w')	
	f.write('output of nlp.py process :(')
	f.close()
	
nlp()
